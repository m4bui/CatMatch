package imageDetection.ImageMatrix;

import com.sun.istack.internal.Nullable;
import imageDetection.Helper.Range;
import imageDetection.ResponseModel.Coordinate;
import imageDetection.ResponseModel.Match;

import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ImageArray {

    protected static final int PERFECT_MATCH = 100;
    protected ArrayList<ArrayList<Coordinate>> mConfidenceValues = new ArrayList<>();

    /**
     *
     */
    public ImageArray() {
        for(int i = 0; i < 101; i++) {
            mConfidenceValues.add(new ArrayList<>());
        }
    }
    /**
     *
     * @param path
     * @param maxRow
     * @param maxCol
     * @return
     */
    //TODO I might want to change this implementation so I can tell the user what the max row and col is
    public ArrayList<String> getPerfectImage(String path, int maxRow, int maxCol) {
        ArrayList<String> perfectCatImage = new ArrayList<>();
        int lineCount = 0;
        try {
            for(String line : Files.readAllLines(Paths.get(path))) {
                if(maxRow > -1) {
                    if(lineCount < maxRow) {
                        //To make a perfect grid
                        while(line.length() < maxCol) {
                            line +=  " ";
                        }
                        perfectCatImage.add(line);
                        lineCount++;
                    } else
                        break;
                } else
                    perfectCatImage.add(line);
            }
        } catch(IOException e) {
            e.printStackTrace();
        }

        return  perfectCatImage;
    }

    /**
     *
     * @return
     */
    public ArrayList<ArrayList<Coordinate>> getConfidenceValues() {
        return mConfidenceValues;
    }

    public void setConfidenceValues( ArrayList<String> mPerfectImage, ArrayList<String> image, int perfectImagePixelCount) {
        for (int row = 0; row < image.size(); row++) {
            for(int col = 0; col < image.get(row).length(); col++) {
                Coordinate coordinate = new Coordinate(row,col);
                mConfidenceValues.get(getConfidenceValue(coordinate, mPerfectImage, image, perfectImagePixelCount)).add(coordinate);
            }
        }
    }

    /**
     *
     * @param startingPoint
     * @param perfectImage
     * @param image
     * @param perfectImagePixelCount
     * @return
     */
    public int getConfidenceValue(Coordinate startingPoint, ArrayList<String> perfectImage, ArrayList<String> image, int perfectImagePixelCount) {
        double confidenceValue = 0;
        int imageDifference = 0;
        int row = startingPoint.getX();
        int col = startingPoint.getY();
        if(image != null && image.size() > 0) {
            for(int i = 0; i < perfectImage.size(); ++i) {
                int imageRow = Math.min(image.size() - 1, row + i);
                int imageCol = Math.min(image.get(imageRow).length(), col);
                int imageColEnd = Math.min(image.get(imageRow).length(), col + 15);
                imageDifference += getDifference(perfectImage.get(i), image.get(imageRow).substring(imageCol, imageColEnd));
            }
            confidenceValue = (perfectImagePixelCount - imageDifference)/(double)perfectImagePixelCount * 100;
        }
        return (int)confidenceValue;
    }

    //TODO test this, issue with reading the whole grid
    /**
     *
     * @param threshold
     * @param confidenceValues
     * @return
     */

    public ArrayList<Match> getAllMatches(int threshold, ArrayList<ArrayList<Coordinate>> confidenceValues) {
        ArrayList<Match> matches = new ArrayList<>(); //contains all matches: coordinates w/ confidence value

        if (confidenceValues == null)
            return matches;

        int currThreshold = PERFECT_MATCH; //start current Threshold at 100: perfect match

        //Start with perfect match and move down to threshold adding in all coordinates that qualify
        while (currThreshold >= threshold) {
            for(Coordinate coordinate : confidenceValues.get(currThreshold)) {
                matches.add(new Match(coordinate, currThreshold));
            }
            currThreshold--;
        }
        return matches;
    }

    /**
     * This is like the hardest part I cry, I don't like the implementation :(
     * I need to calculate all the ranges first and then compare the grid position of the coordinate
     *
     * returns null if there's no matches
     */
    //TODO test this
    public ArrayList<Match> removeOverlappingMatches (int row, int col, ArrayList<Match> matches) {
        final int maxRow = row;
        final int maxCol = col;

        ArrayList<Match> finalMatches = new ArrayList<>(); //all non overlapping matches
        ArrayList<Match> allMatches = matches;

        int gridPosition;
        boolean exists;

        if(allMatches != null && allMatches.size() > 0) { //make sure there's something in the matches to compare to
            finalMatches.add(allMatches.get(0)); //add first point as a starting point
            for(Match match : allMatches) {
                exists = false; //set to false, don't know if the match coordinate is an overlapping image
                Coordinate coordinate = match.getPosition(); //get Coordinate of the existing matches
                gridPosition = getGridPosition(coordinate.getX(), coordinate.getY(), maxCol); //get its grid position

                //compare the current match with the final matches, if it overlaps don't add it
                for (Match finalMatch : finalMatches) {
                    //range of grid values for the coordinate that qualify as the match to be returned
                    ArrayList<Range> ranges = getMatrixArea(finalMatch.getPosition(), maxRow, maxCol);
                    for(Range range : ranges) {
                        //if grid position already exists break don't need to look at the remaining ranges if any
                        if(range.contains(gridPosition)) {
                            exists = true;
                            break;
                        }
                    }

                    //if it exists break don't need to look at the remaining matches in the finalMatch if any
                    if(exists == true)
                        break;
                }

                if(exists == false)
                    finalMatches.add(match);
            }
        }
        return  finalMatches;
    }


    /**
     *
     * @param row
     * @param col
     * @return
     */
    public int getGridPosition(int row, int col, int maxCol) {
        return row * maxCol + col;
    }

    /**
     *
     * @param position
     * @param row
     * @param col
     * @return
     */
    public ArrayList<Range> getMatrixArea (Coordinate position, int row, int col) {
        ArrayList<Range> ranges = new ArrayList<>();
        int x = position.getX();
        int y = position.getY();
        int gridPosition = getGridPosition(x,y, col);
        for(int i = 0; i < row ; i++ ) {
            ranges.add(new Range(gridPosition + col * i  ,(gridPosition + col * i) + col - 1));
        }

        return ranges;
    }


    /**
     *
     * @param string1
     * @param string2
     * @return
     */
    public int getDifference(String string1, String string2) {
        int length = Math.min(string1.length(), string2.length());
        int difference = 0;

        for(int i = 0; i < length; i++) {
            if(string1.charAt(i) != string2.charAt(i)) {
                difference++;
            }
        }

        //TODO I need to redo this logic?
        //If they have different lengths they have a difference in string
        difference += Math.abs(string1.length() - string2.length());
        return difference;
    }



    //--------------------------------------Optimization & Extras --------------------------------------------------------------
    public ArrayList<String> translate90Degrees(ArrayList<String> image, int maxRow, int maxCol) {
        ArrayList<String> newImage = new ArrayList<>();
        int col;
        String str;
        for(col = 0; col < maxCol; col++) {
            int row = maxRow - 1;
            str = "";
            while(row >= 0) {
                if(col + 1 == maxCol)
                    str += image.get(row).substring(maxCol - 1);
                else
                    str += image.get(row).substring(col, Math.min(maxCol - 1, col + 1));
                row--;
            }
            newImage.add(str);
        }
        return newImage;
    }

    public ArrayList<String> translate180Degrees(ArrayList<String> image, int maxRow, int maxCol) {
        int rowIndex;
        String str;
        ArrayList<String> newArray = new ArrayList<>();
        for(rowIndex = maxRow - 1; rowIndex >= 0; rowIndex-- ) {
            str = image.get(rowIndex);
            newArray.add(new StringBuffer(str).reverse().toString());
        }

        return newArray;
    }

    //TODO similar code to 90degrees should refactor
    public ArrayList<String> translate270Degrees(ArrayList<String> image, int maxRow, int maxCol) {
        ArrayList<String> newImage = new ArrayList<>();
        int col;
        String str;
        for(col = maxCol - 1; col >= 0; col--) {
            int row = 0;
            str = "";
            while(row < maxRow) {
                if(col + 1 == maxCol)
                    str += image.get(row).substring(maxCol - 1);
                else
                    str += image.get(row).substring(col, col + 1);
                row++;
            }
            newImage.add(str);
        }
        return newImage;
    }

    //TODO Move the methods below into their own helper class
    /**
     * Helper Method to print Image for a visual sanity check
     * @param imageArray
     */

    /**
     *  get max possible matches given perfect cat image and image frame
     */
    //TODO option Optimization, doesn't account for rotation
    public int getMaxPossiblePerfectImages(int row, int col, int  perfectPixelCount) {
        if(perfectPixelCount == 0 || row * col == 0) //can't divide by 0, return 0 for no matches
            return  0;
        else if(row * col < perfectPixelCount) //less than actual image means you can only find one possible match (a partial one)
            return  1;

        return (row * col) / perfectPixelCount;
//        return (mClientImageCol * mClientImageRow) / PERFECT_CAT_PIXEL_COUNT;
    }

    //TODO row is = or > actual but col isn't
    // TODO col is = or > actual but row isn't
    public int getMaxPossiblePerfectImageAlpha(int row, int col, int actualRow, int actualCol) {
        //if there's an empty given image or the actual image to compare to is 0 return 0, no possible match
        if(row == 0 && col == 0 || actualRow == 0 && actualCol == 0)
            return 0;
            //if the image matrix is smaller than the expected image return 1, there will be at most one partial match
        else if(actualRow < row && actualCol < col) {
            return 1;
        }
        //the given matrix is at least the size of the actual image. Return the max matches taking into consideration
        //partial matches from the col and row in excess of the actual image
        else {
            int stuffrow = 0;
            int stuffCol = 0;
            if(row % actualRow != 0)
                stuffCol = col % actualCol;
            if(col % actualCol != 0)
                stuffrow = row % actualRow;
        }

        return 1;
    }

    public void printImage(ArrayList<String> imageArray) {
        for (String string : imageArray) {
            System.out.println(string);
        }
    }
}
