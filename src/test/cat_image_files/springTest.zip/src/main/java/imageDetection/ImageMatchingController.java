package imageDetection;

import imageDetection.ImageMatrix.CatImageArray;
import imageDetection.ResponseModel.Coordinate;
import imageDetection.ResponseModel.Match;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicLong;

@RestController
public class ImageMatchingController {

    //TODO Multipart Resolver?
    //TODO limit file upload
    /**
     * The Image Detection API detects cat images given a text file
     */
    private final AtomicLong counter = new AtomicLong();
    private final String version = "/imageDetect/v1";
    @RequestMapping("/")
    public String defaultPage(@RequestParam(value="name", defaultValue="Intuit") String name) {
        return "imageDetection";
    }

    @RequestMapping(value = version + "/cat", method = RequestMethod.POST, consumes = "multipart/form-data", produces="application/json")
    public ResponseEntity<ArrayList<Match>> create(@RequestParam("file") MultipartFile file, @RequestParam(value = "threshold", defaultValue = "100") int threshold) {
        System.out.println("---------INSIDE ORDER----------");
        //Coordinate Matches and Confidence value to be returned
        ArrayList<Match> matches = new ArrayList<>();
        //get array list representation of image frame
        CatImageArray catImageArray = new CatImageArray(file, threshold);

        return new ResponseEntity<>(matches, HttpStatus.OK);
    }
}

