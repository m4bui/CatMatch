package imageDetection.ImageMatrix;


import imageDetection.ResponseModel.Coordinate;
import imageDetection.ResponseModel.Match;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;

public class CatImageArray extends ImageArray {

    public static final int PERFECT_CAT_ROW_COUNT = 13;
    public static final int PERFECT_CAT_COL_COUNT = 15;
    public static final int PERFECT_CAT_PIXEL_COUNT = PERFECT_CAT_ROW_COUNT * PERFECT_CAT_COL_COUNT; //13x15

    public static final String perfectCatPath = "/Users/michellebui/Desktop/cat_match/perfect_cat_image.txt";

    private ArrayList<String> mPerfectCatImage = new ArrayList<>();
    private ArrayList<String> mImage = new ArrayList<>();

    private int mClientImageRow = 0;
    private int mClientImageCol = 0;
    private int mThreshold = 85; //if user doesn't specify confidence value will set it to this default value

    public CatImageArray(MultipartFile file, int threshold) {
        //call parent class to initalize the confidence values 0 - 100
        super();
        mPerfectCatImage = getPerfectImage(perfectCatPath, PERFECT_CAT_ROW_COUNT, PERFECT_CAT_COL_COUNT);

        if(threshold > -1)
            this.mThreshold = threshold;
        setImageArray(file);
        System.out.println("file name is: " + file.getName());
        System.out.println("original file name is: " + file.getOriginalFilename());

    }

    public ArrayList<String> setImageArray(MultipartFile file) {
        ArrayList<String> image = new ArrayList<>();
        try {
            InputStream inputStream = file.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            String line; //to read lines from file
            int maxLength = 0; //file's longest string

            while ((line = bufferedReader.readLine()) != null)
            {
                //save the longest string length to use as col
                maxLength = Math.max(maxLength, line.length());

                //character that doesn't exist in the file this is to account for the case when there's an empty line
                if(line.length() == 0)
                    image.add("z");
                else
                    image.add(line);
            }

            if(image != null)
                mClientImageRow = image.size();

            if(mImage.size() > 0)
                mClientImageCol = maxLength;

//            setConfidenceValues(image);

        } catch(IOException e) {
            e.printStackTrace();
        }

        return image;
    }

//    public ArrayList<String> getPerfectImage(String path) {
//        ArrayList<String> perfectCatImage = new ArrayList<>();
//        int lineCount = 0;
//        try {
//            //TODO Change the file of the path
//            for(String line : Files.readAllLines(Paths.get(path))) {
//                if(lineCount < PERFECT_CAT_ROW_COUNT) {
//                    perfectCatImage.add(line);
//                    lineCount++;
//                } else
//                    break;
//            }
//        } catch(IOException e) {
//            e.printStackTrace();
//        }
//
//        return  perfectCatImage;
//    }
//
//    public void setImageArray(MultipartFile file) {
//        try {
//            InputStream inputStream = file.getInputStream();
//            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
//
//            String line; //to read lines from file
//            int maxLength = 0; //file's longest string
//
//            while ((line = bufferedReader.readLine()) != null)
//            {
//                //save the longest string length to use as col
//                maxLength = Math.max(maxLength, line.length());
//
//                //character that doesn't exist in the file this is to account for the case when there's an empty line
//                if(line.length() == 0)
//                    mImage.add("z");
//                else
//                    mImage.add(line);
//            }
//
//            if(mImage != null)
//                mClientImageRow = mImage.size();
//
//            if(mImage.size() > 0)
//                mClientImageCol = maxLength;
//
//            //TODO
////            setConfidenceValues();
//
//        } catch(IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    public ArrayList<ArrayList<Coordinate>> getConfidenceValues() {
//        return mConfidenceValues;
//    }
//
//    public ArrayList<String> getImage() {
//        return mImage;
//    }
//
//    public ArrayList<String> getPerfectCatImage() {
//        return mPerfectCatImage;
//    }
//
//    public int getClientImageRow () {
//        return  mClientImageRow;
//    }
//
//    public int getClientImageCol() {
//        return mClientImageCol;
//    }
//
//    public void setConfidenceValues(ArrayList<String> image) {
//        for (int row = 0; row < image.size(); row++) {
////            System.out.println("setting row: " + row);
//            for(int col = 0; col < image.get(row).length(); col++) {
////                System.out.println("setting coordinate row: " + row + " and col: " + col);
//                Coordinate coordinate = new Coordinate(row,col);
////                ArrayList<Range> ranges = new ArrayList<>();
////                coordinate.setRanges(getRanges(coordinate, row, col));
////                System.out.println("confidence value is"  + getConfidenceValue(coordinate, image));
//                mConfidenceValues.get(getConfidenceValue(coordinate, image)).add(coordinate);
////                System.out.println("Confidence value is: " + getConfidenceValue(coordinate, image));
////                System.out.println("Coordinate is: " + coordinate.getX() +  "," + coordinate.getY());
//            }
//        }
//
//    }
//
//    //TODO The problem is row 13 has size 0 should remember this when calculating the percentages since I'll be without a row
//    private int getConfidenceValue(Coordinate startingPoint, ArrayList<String> image) {
//        double confidenceValue;
//        int imageDifference = 0;
//        int row = startingPoint.getX();
//        int col = startingPoint.getY();
//        for(int i = 0; i < PERFECT_CAT_ROW_COUNT; ++i) {
//            int imageRow = Math.min(image.size() - 1, row + i);
//            int imageCol = Math.min(image.get(imageRow).length(), col);
//            int imageColEnd = Math.min(image.get(imageRow).length(), col + 15);
//            imageDifference += getDifference(mPerfectCatImage.get(i), image.get(imageRow).substring(imageCol, imageColEnd));
//        }
//        confidenceValue = (PERFECT_CAT_PIXEL_COUNT - imageDifference)/(double)PERFECT_CAT_PIXEL_COUNT * 100;
//        return (int)confidenceValue;
//    }
//
//    private int getDifference(String string1, String string2) {
//        int length = Math.min(string1.length(), string2.length());
//        int difference = 0;
//
//        for(int i = 0; i < length; i++) {
//           if(string1.charAt(i) != string2.charAt(i)) {
//               difference++;
//           }
//        }
//
//        //TODO I need to redo this logic
//        //If they have different lengths they have a difference in string
//        difference += Math.abs(string1.length() - string2.length());
//        return difference;
//    }
//
//
//    /**
//     *  get max possible matches given perfect cat image and image frame
//     */
//    private int getMaxPossiblePerfectImages() {
//        return (mClientImageCol * mClientImageRow) / PERFECT_CAT_PIXEL_COUNT;
//    }
//
//    /**
//     * This is like the hardest part I cry, I don't like the implementation :(
//     * I need to calculate all the ranges first and then compare the grid position of the coordinate
//     */
//    private void removeOverlappingMatches () {
//        ArrayList<Match> finalMatches = new ArrayList<>();
//        ArrayList<Match> allMatches = getAllCatMatches();
//
//        int maxImages = getMaxPossiblePerfectImages();
//        int gridPosition;
//
//        if(allMatches != null && allMatches.size() > 0) {
//            finalMatches.add(allMatches.get(0)); //add first point as a starting point
//
//            //iterate over matches and only add the ones that don't already exist on the grid of final matches
//            //allMatches is garunteed to be in descending order so you're looking for best matches first
//            for(Match match : allMatches) {
//                Coordinate coordinate = match.getPosition();
//                gridPosition = getGridPosition(coordinate.getX(), coordinate.getY());
//
//                for (Match finalMatch : finalMatches) {
//                    //find the ranges of the finalMatch values and see if the grid position fits
//                    ArrayList<Integer> ranges = new ArrayList<>();
//                    // TODO off by one
//                    for(int i = 1; i < mClientImageRow + 1; i++) {
//                        int start = i * getGridPosition(finalMatch.getPosition().getX(), finalMatch.getPosition().getY());
//                        int end = start + mClientImageCol;
//                        if(start < gridPosition && gridPosition < end) {
//                            //this is an overlap
//                        } else {
//                            finalMatches.add(finalMatch);
//                        }
//                    }
//                }
//            }
//        }
//
//    }
//
//
//    /**
//     *
//     * @param row
//     * @param col
//     * @return
//     */
//    private int getGridPosition(int row, int col) {
//        return row * mClientImageCol + col;
//    }
//
//    //TODO test this range function. This just gives you the ranges does not account for out of intdex values
//    private ArrayList<Range> getRanges (Coordinate position, int row, int col) {
//        ArrayList<Range> ranges = new ArrayList<>();
//        int x = position.getX();
//        int y = position.getY();
//        for(int i = 0; i < row; i++ ) {
//            ranges.add(new Range(x + i , y + col));
//        }
//
//        return ranges;
//    }
//
//
//    //I'll be given x,y I need to calculate the space it takes 1,3 -> 2,2 ->
//    public ArrayList<Match> getAllCatMatches() {
//        ArrayList<Match> matches = new ArrayList<>(); //contains all matches: coordinates w/ confidence value
//
//        int currThreshold = PERFECT_MATCH; //start current Threshold at 100: perfect match
//
//        //Start with perfect match and move down to threshold adding in all coordinates that qualify
//        while (currThreshold >= mThreshold) {
//            for(Coordinate coordinate : mConfidenceValues.get(currThreshold)) {
//                matches.add(new Match(coordinate, currThreshold));
//            }
//            currThreshold--;
//        }
//
//        return matches;
//    }
//
//    //TODO Move the methods below into their own helper class
//
//    /**
//     * Helper Method to print Image for a visual sanity check
//     * @param imageArray
//     */
//    public void printImage(ArrayList<String> imageArray) {
//        for (String string : imageArray) {
//            System.out.println(string);
//        }
//    }

}
