package imageDetectionTests;

import imageDetection.Helper.Range;
import imageDetection.ImageMatrix.CatImageArray;
import imageDetection.ImageMatrix.ImageArray;
import imageDetection.ResponseModel.Coordinate;
import imageDetection.ResponseModel.Match;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.awt.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@RunWith(SpringJUnit4ClassRunner.class)
public class ImageArrayTest {

    private String fileDir = "/Users/michellebui/Desktop/cat_match/";
//    Should_ExpectedBehavior_When_StateUnderTest
    private ImageArray mImageArray;
    private ArrayList<String > mPerfectCatImage;

    @Before
    public void setUp() {
        mImageArray = new ImageArray();
        mPerfectCatImage = mImageArray.getPerfectImage(CatImageArray.perfectCatPath, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);

    }

    /**
     *  sanity check tests
     */

    @Test
    public void Should_ReturnAllRowsWithSameLength_When_RowColSpecified() {
        for(String string : mPerfectCatImage) {
            assertEquals(CatImageArray.PERFECT_CAT_COL_COUNT, string.length());
        }
    }

    @Test
    public void Should_ReturnImageWithSpecifiedMaxRow_When_MaxRowSpecified() {
        ArrayList<String> image = mImageArray.getPerfectImage(CatImageArray.perfectCatPath, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        assertEquals(CatImageArray.PERFECT_CAT_ROW_COUNT, image.size());
    }

    /**
     * getConfidenceValues() test
     */

    @Test
    public void Should_BeSize101_When_ImageArrayInstantiated() {
        assertEquals(101, mImageArray.getConfidenceValues().size());
    }


    /**
     *  getConfidenceValue() Tests
     */
    @Test //General level of confidence test case
    public void Should_Return100_When_CalledWithSameImage() {
        Coordinate origin = new Coordinate(0,0);
        ArrayList<String> image = mImageArray.getPerfectImage(CatImageArray.perfectCatPath, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        int condfidenceValue = mImageArray.getConfidenceValue(origin, image, image, CatImageArray.PERFECT_CAT_PIXEL_COUNT );
        assertEquals(100, condfidenceValue);
    }

    @Test
    public void Should_Return0_When_CalledWithEmptyFile() throws Exception {
        ArrayList<String> emptyfile = new ArrayList<>();
        Coordinate origin = new Coordinate(0,0);
        confidenceValueTest(emptyfile, origin,0);
    }

    @Test
    public void Should_Return50_When_CalledWith98FilledPixels() throws Exception {
        ArrayList<String> fiftyPercentImageFile = new ArrayList<>();
        Coordinate origin = new Coordinate(0,0);
        int rows = 98 /CatImageArray.PERFECT_CAT_COL_COUNT; // 6.5 -> 6
        int col =  98 % CatImageArray.PERFECT_CAT_COL_COUNT ; // 8
        for(int row = 0; row < rows; row++) {
            fiftyPercentImageFile.add(mPerfectCatImage.get(row));
        }

        String lastCopy = mPerfectCatImage.get(rows).substring(0, col);
        for(int i = 0; i < CatImageArray.PERFECT_CAT_COL_COUNT - col; i++) {
            lastCopy += "z";
        }

        fiftyPercentImageFile.add(lastCopy);

        String filler = "";
        for(int i = 0; i <= CatImageArray.PERFECT_CAT_COL_COUNT; i++) {
            filler += "z";
        }

        for(int row = rows; row < CatImageArray.PERFECT_CAT_ROW_COUNT; row++) {
            fiftyPercentImageFile.add(filler);
        }

        for(String line : fiftyPercentImageFile) {
            System.out.println(line);
        }

        confidenceValueTest(fiftyPercentImageFile, origin,50);
    }

    /**
     *  getDifference() Tests
     */
    @Test
    public void Should_Return3_When_ComparingAttackWithAttackbcd() {
        int difference = mImageArray.getDifference("Attack", "Attackbcd");
        assertEquals(3, difference);
    }

    @Test
    public void Should_Return2_When_ComparingYumWithY() {
        assertEquals(2, mImageArray.getDifference("Yum", "Y"));
    }

    @Test
    public void Should_ReturnStringLength_When_ComparingStringWithEmptyString() {
        String string = "ThisIsAString";
        String emptyString = "";
        assertEquals(string.length(), mImageArray.getDifference(string, emptyString));
    }


    //Helper Method to get Confidence Value
    public void confidenceValueTest(ArrayList<String> imageToCompare, Coordinate coordinate, int expected) {
        ArrayList<String> image = mImageArray.getPerfectImage(CatImageArray.perfectCatPath, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        int confidenceValue = mImageArray.getConfidenceValue(coordinate, image, imageToCompare, CatImageArray.PERFECT_CAT_PIXEL_COUNT);
        assertEquals(expected, confidenceValue);

    }

    /**
     *  getMaxPossiblePerfectImages
     */
    @Test
    public void Should_Return1_When_5x3ComparedWith195() {
        int maxMatches = mImageArray.getMaxPossiblePerfectImages(5,3, 195);
        assertEquals(1, maxMatches);
    }

    @Test
    public void Should_Return0_When_0ComparedWith195() {
        assertEquals(0, mImageArray.getMaxPossiblePerfectImages(0,0, 195));
    }

    @Test
    public void Should_Return0_When_100ComparedWithEmptyImage() {
        assertEquals(0, mImageArray.getMaxPossiblePerfectImages(10,10, 0));
    }

    @Test
    public void Should_Return25_When_65x75PerfectImageArea() {
        assertEquals(25, mImageArray.getMaxPossiblePerfectImages(65,75, 195));
    }


    /**
     *  getGridPosition
     */
    @Test
    public void Should_ReturnPosition5_WhenCoordinatex0y5() {
        assertEquals(5, mImageArray.getGridPosition(0,5, CatImageArray.PERFECT_CAT_COL_COUNT));
    }

    //TODO rename this
    @Test
    public void Should_ReturnPositionX_Coordinatex2y2() {
        assertEquals(32, mImageArray.getGridPosition(2,2, CatImageArray.PERFECT_CAT_COL_COUNT));
        assertEquals(11, mImageArray.getGridPosition(0,11, CatImageArray.PERFECT_CAT_COL_COUNT));
        assertEquals(29, mImageArray.getGridPosition(1,14, CatImageArray.PERFECT_CAT_COL_COUNT));
    }

    @Test
    public void Should_Contain11_Coordinatex0y0() {
        Coordinate coordinate = new Coordinate(0,0);
        ArrayList<Range> ranges = mImageArray.getMatrixArea(coordinate, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        assertEquals(true, ranges.get(0).contains(11));
        for (Range range : ranges) {
            System.out.println("Range is: " + range.getLow() + "-" + range.getHigh());
        }
        System.out.println("low is: " + ranges.get(1).getLow() + " high is " + ranges.get(1).getHigh());
        assertEquals(true, ranges.get(1).contains(18));
    }
    /**
     * test getRanges for a given coordinate to see what area it covers
     */
    //TODO need to come up with a better name
    @Test
    public void Should_ReturnArea_When_GiveCoordinate () {
        Coordinate coordinate = new Coordinate(0,0 );
        ArrayList<Range> ranges = mImageArray.getMatrixArea(coordinate, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);


        for(Range range : ranges) {
            int position = mImageArray.getGridPosition(0, 0, CatImageArray.PERFECT_CAT_COL_COUNT);
            if(range.contains(position)) {
                System.out.println("low is: " + range.getLow() + " high is: " + range.getHigh() + " position: " + position);
            }
        }

    }

    @Test
    public void translate90DegreesTest() {
        ArrayList<String> translatedImage = mImageArray.translate90Degrees(mPerfectCatImage, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        System.out.println("****************************90 degrees ********************************");
        for (String string : translatedImage)
            System.out.println(string);
    }

    @Test
    public void translate180DegreesTest() {
        ArrayList<String> translatedImage = mImageArray.translate180Degrees(mPerfectCatImage, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        for (String string : translatedImage)
            System.out.println(string);
    }

    @Test
    public void translate270DegreesTest() {
        ArrayList<String> translatedImage = mImageArray.translate270Degrees(mPerfectCatImage, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);
        System.out.println("**************************** 270 degrees ********************************");
        for (String string : translatedImage)
            System.out.println(string);
    }

    //TODO remove this is integration testing
    @Test
    public void getMatches() {
        ArrayList<String> image = mImageArray.getPerfectImage(CatImageArray.perfectCatPath, CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT);

        mImageArray.setConfidenceValues(mPerfectCatImage, image, CatImageArray.PERFECT_CAT_PIXEL_COUNT );
        ArrayList<ArrayList<Coordinate>> confidenceValues = mImageArray.getConfidenceValues();
        ArrayList<Match> matches = mImageArray.getAllMatches(0, confidenceValues);
//        for (Match match : matches) {
//            System.out.println("coordinate is: " + match.getPosition().getX() + "," + match.getPosition().getY() + " with confidence value: " + match.getConfidenceValue());
//        }

        ArrayList<Match> finalMatches = mImageArray.removeOverlappingMatches(CatImageArray.PERFECT_CAT_ROW_COUNT, CatImageArray.PERFECT_CAT_COL_COUNT, matches);
        for (Match match : finalMatches)
            System.out.println("coordinate is: " + match.getPosition().getX() + "," + match.getPosition().getY() + " with confidence value: " + match.getConfidenceValue());

    }

}
