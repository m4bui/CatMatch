package imageDetectionTests;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
public class ImageMatchingControllerIT {
    @Test
    public void testConfidenceValues() throws Exception {
        String fileDir = "/Users/michellebui/Desktop/cat_match/";
        String catFiles = "_cat_image.txt";
//TODO add this back when you're done unit testing
//        for(int i = 0; i < CatImageArray.PERFECT_CAT_PIXEL_COUNT; i++) {
//            double expectConfidenceValue = (i / (double)CatImageArray.PERFECT_CAT_PIXEL_COUNT) * 100;
//            String catFile = String.valueOf(i) + catFiles;
//            FileInputStream fis = new FileInputStream(fileDir + catFile);
//            MockMultipartFile multipartFile = new MockMultipartFile(catFile, fis);
//            ImageMatchingController controller  = new ImageMatchingController();
//            ResponseEntity<ArrayList<Match>> responseEntity = controller.create(multipartFile, 0);
//            ArrayList<Match> matches = responseEntity.getBody();
//
//            if(i == 0) {
//                System.out.println("Matches size is: " + matches.size());
//                System.out.println("Status code is: " + responseEntity.getStatusCode());
//            }
//
//            for(Match match : matches) {
//                String coordinateErr = match.getPosition().getX() + "," + match.getPosition().getY();
//                if (match.getPosition().getX() == 0 && match.getPosition().getY() == 0)
//                    assertEquals("Percentage doesn't match for coordinate: " + coordinateErr, (int)expectConfidenceValue, match.getConfidenceValue());
//            }
//        }
    }

    @Test
    public void testResultArraySize() throws Exception {

    }

}
